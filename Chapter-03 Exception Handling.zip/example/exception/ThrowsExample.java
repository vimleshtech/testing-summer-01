package example.exception;

public class ThrowsExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
