package questions;

public class Calc extends InheritenceEx {
	
	void mul(int a, int b) {
		System.out.println(a*b);
	}

}
