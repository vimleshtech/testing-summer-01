package questions;

public class ModifierExample {

	
	int a;
	final int b=100;  //we must to assign value
	static String name;
	
	final int age=18;
	
	void test()
	{
		//b = 1110; //we cannot change/modify
		a =334334; //we can change the value
		
	}
	
	
	static void test2() {
		System.out.println("test -2 ");
	}
	
	
	
	
}
