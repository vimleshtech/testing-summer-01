package questions;

public class Caller {

	public static void main(String[] args) {
		
		ModifierExample e = new ModifierExample();
		ModifierExample e1 = new ModifierExample();
		
		e.a =1;
		//e.b =44;
		e.name ="fkjfh";
		e.test();
		e.test2();
		
		e1.a =33;
		e1.name ="jatin";  //data wil be change for e object 
		
		System.out.println(e.a);  //  1
		System.out.println(e.name);// jatin
		System.out.println(e1.a);// 33
		System.out.println(e1.name);// jatin 
				

		//can be access without object
		ModifierExample.test2();
		ModifierExample.name ="skjhss";
		
	
		///
		ThisExample o = new ThisExample();
		o.setData(100, "rahul");
		o.getData();
		
		
		//object of child class
		InheritenceEx in = new InheritenceEx();
		in.add(11, 22);
		in.hello();
	
		//create object of third child class
		Calc c = new Calc();
		c.mul(11, 3);
		c.add(11, 2);
		c.hello();
	}
	
	

}
