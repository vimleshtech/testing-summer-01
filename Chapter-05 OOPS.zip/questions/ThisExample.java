package questions;

public class ThisExample {

	int id;
	String name;
	
	void setData(int id, String name) {	
		this.id =id;
		this.name = name;
	}
	void getData() {
		
		System.out.println(id);
		System.out.println(name);
	}
	
}
