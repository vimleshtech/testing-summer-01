package questions;


class Test{
	
	void hello() {
		System.out.println("hello");
	}
}
public class InheritenceEx  extends Test{

	void add(int a, int b) {
		System.out.println(a+b);
	}
	
}
