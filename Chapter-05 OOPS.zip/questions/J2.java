package questions;

public class J2 {

	public static void main(String[] a) {
	
		Emp o[] = new Emp[10]; //declare array of Class
		
		for(int i=0; i<10;i++) {
			
			o[i] = new Emp(); // create instance of class
			o[i].Input();
			o[i].calc();
		}
		
		for(Emp e : o) {
			e.disp();
		}
		
	}
}
