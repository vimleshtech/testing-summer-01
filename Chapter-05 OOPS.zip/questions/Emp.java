package questions;

import java.util.Scanner;

public class Emp {

	private int Ecode;//			integer				
	private String Ename;			
	private int Basic_salary;		
	private float Hra;//			float			40% of basic salary
	private float Da;// 			float			20% of basic salary
	private float Ta;//			float			10% of basic salary
	private float Gross_salary;//		float			basic salary + hra + da + ta
	private float It;//			20 % of gross salary	
	private float Pf;//			float			10% of gross salary
	private float Net_salary;		//float			gross salary � (it + pf)

	
	void Input( )//		- function to input the values for
	{

		Scanner sc =new Scanner(System.in);
		System.out.println("enter ecode ");
		Ecode = sc.nextInt();
		
		System.out.println("enter name ");
		Ename = sc.next();
		
		System.out.println("enter basic sal ");
		Basic_salary = sc.nextInt();
		
	}

	void calc( )//		- function to calculate all other values
	{
		
		Hra = Basic_salary*.40f;
		Da = Basic_salary*.20f;
		Ta = Basic_salary*.10f;
		Gross_salary = Basic_salary+Hra+Da+Ta;
		It = Gross_salary*.20f;
		Pf = Gross_salary*.10f;
		Net_salary = Gross_salary - (It+Pf);
		
		
	}
	void disp( )//		- function to display the all the values.
	{
		
		System.out.println("e code "+Ecode);
		System.out.println("e name "+Ename);
		System.out.println("e Gross sal "+Gross_salary);
		System.out.println("e Income tax "+It);
		System.out.println("e pf "+Pf);
		System.out.println("e net sal "+Net_salary);
	}



}
