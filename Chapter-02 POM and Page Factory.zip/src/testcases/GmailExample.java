package testcases;

import projectutils.*;
import org.testng.annotations.Test;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;

import java.util.Properties;

import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.AfterSuite;

public class GmailExample {
	
  static Properties prop;
  
	
  @Test(priority=1)
  public void GoogleHomePage() {
	  
	  
	  System.out.println(prop.getProperty("searchbox"));
	  System.out.println(prop.getProperty("btnaction"));
	  
	  
  }

  @Test(priority=2)
  public void GmailLogin() {
	  
	  System.out.println(prop.getProperty("emailid"));
	  System.out.println(prop.getProperty("next"));
	  
	
	  
  }
  
  
  @BeforeMethod
  public void beforeMethod() {
  }

  @AfterMethod
  public void afterMethod() {
  }

  @BeforeClass
  public void beforeClass() {
  }

  @AfterClass
  public void afterClass() {
  }

  @BeforeTest
  public void beforeTest() {
	  
	  prop = ObjectHandler.loadProp();
	  
	  //DirsedCap.
	  
  }

  @AfterTest
  public void afterTest() {
  }

  @BeforeSuite
  public void beforeSuite() {
  }

  @AfterSuite
  public void afterSuite() {
  }

}
