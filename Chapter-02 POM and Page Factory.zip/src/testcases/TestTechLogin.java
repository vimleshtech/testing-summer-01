package testcases;

import org.testng.annotations.Test;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeTest;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;

import org.openqa.selenium.firefox.FirefoxDriver;

import org.testng.Assert;

import org.testng.annotations.BeforeTest;

import org.testng.annotations.Test;

import pages.TechLogin;


public class TestTechLogin {
	
	WebDriver driver;

    TechLogin objLogin;
    
  @Test(priority=0)
  public void f() {
	  
	  //Create Login Page object

	    objLogin = new TechLogin(driver);

	    //Verify login page title
	    String loginPageTitle = objLogin.getLoginTitle();

	    Assert.assertTrue(loginPageTitle.toLowerCase().contains("Login -Tech Vision ERP v 1.2"));
	    //login to application
	    objLogin.loginToTech("chahat", "Test@123");

	    
  }
  @AfterMethod
  public void afterMethod() {
  }

  @BeforeTest
  public void beforeTest() {
	  
	  driver = new FirefoxDriver();

      driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

      driver.get("http://erp.techvisionit.com/");
      
  }

}
