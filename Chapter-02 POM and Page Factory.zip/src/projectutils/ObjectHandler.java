package projectutils;

import java.io.FileInputStream;
import java.util.Properties;

public class ObjectHandler {

	

	
	public static Properties loadProp() {
		
		Properties prop =null;
		
		try
		{
			//FileInput Reader
			FileInputStream fs =new FileInputStream("C:\\Users\\vkumar15\\eclipse\\PageObjectFramework\\src\\objects\\pageobjects.properties");
			prop = new Properties();  //instance of Properties class
			prop.load(fs);  //load file to properties 
			
		
		}
		catch (Exception e) {
			
			System.out.println(e.toString());
		}
		return prop;
		
		
	}
	
}
