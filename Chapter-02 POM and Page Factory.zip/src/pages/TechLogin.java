package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class TechLogin {
	
	//Declaration of webdriver object
	WebDriver driver;	
	//constructor : is function which invokes automatically 
	public TechLogin(WebDriver driver){  //Constructor overloading				
		this.driver = driver;
	}

    By userTechName = By.name("txtUserName");
    By passwordTech = By.name("txtPassword");
    By login = By.id("btnSubmit");    
    By msgText =By.id("lblmsg");
    
  //Set user name in textbox
    public void setUserName(String strUserName){

        driver.findElement(userTechName).sendKeys(strUserName);

    }

    //Set password in password textbox
    public void setPassword(String strPassword){
         driver.findElement(passwordTech).sendKeys(strPassword);
    }

    //Click on login button
    public void clickLogin(){
            driver.findElement(login).click();
    }
    //Get the title of Login Page
    public String getLoginTitle(){

    	
    	try {
    		return driver.findElement(msgText).getText();
    	}
    	catch (Exception e) {
			// TODO: handle exception
    			return driver.getTitle();
		}
    	
    }
    
    
    public String loginToTech(String strUserName,String strPasword){

        //Fill user name
        this.setUserName(strUserName);
        //Fill password
        this.setPassword(strPasword);
        //Click Login button
        this.clickLogin();  
        
        String msg = this.getLoginTitle();
        return msg;
    }
    
	
}
