package example;

public class User {

	private int uid;
	private String uname;
	private String uemail;
	private String upwd;
	
	//cosntructor //is function which invokes automatically when object will create 
	User (int uid, String uname, String uemail, String upwd){
	
		this.uid = uid;
		this.uname = uname;
		this.uemail = uemail;
		this.upwd = upwd;
	}
	
	public void userInfo() {
		System.out.println("User Details "+this.uid+" name "+this.uname+" email "+this.uemail+" password "+this.upwd);
	}
}
