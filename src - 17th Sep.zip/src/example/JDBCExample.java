package example;

import java.net.SocketTimeoutException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.PreparedStatement;

public class JDBCExample {

	public static void main(String[] args) {

		
		try {
			
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost/test_con","root","root");
			Statement st = con.createStatement();
			ResultSet rs =  st.executeQuery("select * from emp");
			
			//
			while(rs.next()) {
				System.out.println(rs.getString(1) + rs.getString(2));
			}
			
					
		}
		catch (Exception e) {
			// TODO: handle exception
			System.out.println(e.toString());
		}
		

	}

}
