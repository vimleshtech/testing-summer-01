package example;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		//object of Product class
		Product p = new Product();
		//p.pid =1;//cannot be accessed 
		p.newProduct();
		p.dispProduct();
		
	}

}
