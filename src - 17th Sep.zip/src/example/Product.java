package example;

import java.util.Scanner;

//class
public class Product {

	//data member 
	private int pid;
	private String pname;
	private double price;
	
	//methods or data member
	public void newProduct() {
		
		Scanner sc = new Scanner(System.in);
		
		System.out.println("enter product id");
		this.pid  = sc.nextInt();
		
		System.out.println("enter product name");
		this.pname  = sc.next();
		
		System.out.println("enter product price");
		this.price  = sc.nextDouble();
		
	}
	public void dispProduct() {
		
		System.out.println("Product id "+this.pid);
		System.out.println("Product name "+this.pname);
		System.out.println("Product price "+this.price);
		
	}
	
	
}
