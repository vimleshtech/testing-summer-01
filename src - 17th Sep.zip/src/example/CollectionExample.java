package example;

import java.util.*;

public class CollectionExample {

	public static void main(String[] args) {
		//ArrayList
		//dynamic type and size
		ArrayList al = new ArrayList();
		al.add(11);
		al.add(11);
		al.add(true);
		al.add(555.33);
		al.add("test");
		
		System.out.println(al.size()); 
		System.out.println(al.get(0));//return first value
		
		//iterrate the element
		for(int i=0; i<al.size();i++) {
			System.out.println(al.get(i));
		}

		//
		al.remove(1);
		System.out.println(al.size());
		
		//List
		List l = new ArrayList();
		l.add(555.33);
		l.add("test");
		System.out.println(l.size());
		
		//
		List<String> ls = new ArrayList<String>();//declare with string prototype
		ls.add("hi");
		ls.add("hi1");
		ls.add("hi3");
		ls.add("hi4");
		System.out.println(ls.size());

		//
		Set<String> ss = null;
		
		//HashMap
		HashMap m = new HashMap();
		m.put("a", 100);
		m.put(1, "one");
		
		System.out.println(m.size());
		System.out.println(m.get("a"));
		
		///
		HashMap<Integer, String> hm = new HashMap<>();
		hm.put(11, "fkjf");
		
		///Custom user defined prototype
		List<User> u = new ArrayList<User>();
		u.add(new User(1,"nitin","nitin@gmail.com","pwd1"));
		u.add(new User(2,"jatin","jatin@gmail.com","pwd11"));
		u.add(new User(3,"divya","divya@gmail.com","pwd31"));
		u.add(new User(4,"ayush","ayush@gmail.com","4pwd1"));
		u.add(new User(5,"mohit","mohit@gmail.com","pwd1"));
		
		for(int i=0;i<u.size();i++) {
			u.get(i).userInfo();
		}
		
		//or
		for(User uo : u) {
			uo.userInfo();
		}
	}

}
